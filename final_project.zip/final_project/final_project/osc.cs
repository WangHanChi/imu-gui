﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.IO.Ports;

namespace Osc
{
    public enum Status 
    {
        NO_COM = 0,
        DIS_COM = 1,
        NOKNOWN_SENSER = 2,
        PRE_START = 3,
        GET_VALUE = 4,
        NO_DATA = 5,
        STOP_GET_VALUE = 6
    }

    public enum Errorcodes
    { 
        NO_COM = 0,
        COＭ_SUSS = 1,
        COM_FAL = 2,
        INIT = 3,
        NONE = 4,
    }

    public enum Section
    { 
        ACC = 0,
        GY = 1,
        TEMP = 2,
        INIT = 3
    }

    public class Data
    {
        public double Data_count;
        protected Graphics g;
    }
    public class Acc : Data
    {
        public double Acc_x;
        public double Acc_y;
        public double Acc_z;
        

        public Acc(double acc_x, double acc_y, double acc_z)
        { 
            this.Acc_x = acc_x;
            this.Acc_y = acc_y;
            this.Acc_z = acc_z;
            
        }

        

        //剩下Draw、closeprofile
    }

    public class Gy : Data
    { 
        public double Gy_x;
        public double Gy_y;
        public double Gy_z;
        
        public Gy(double gy_x, double gy_y, double gy_z, Graphics gIn)
        { 
            this.Gy_x = gy_x;
            this.Gy_y = gy_y;
            this.Gy_z = gy_z;
            this.g = gIn;
            
        }


        
        public void draw()
        {
            
            Point center = new Point(300, 300);
            //Pen pen = new Pen(Color.Brown, 5);
            //g.DrawArc(pen, center.X, center.Y, 50, 50, 0, 270);
            SolidBrush brushText = new SolidBrush(Color.Black);
            Font FontText = new Font("Arial", 12);

            g.DrawString(Gy_x.ToString(), FontText, brushText, center.X, center.Y);
            g.DrawString(Gy_y.ToString(), FontText, brushText, center.X, center.Y + 50);
            g.DrawString(Gy_z.ToString(), FontText, brushText, center.X, center.Y + 100);
            g.DrawString(Data_count.ToString(), FontText, brushText, center.X, center.Y + 150);
            Console.WriteLine(Data_count);
            //x軸的角度先設為5度，y軸的先設為20度，z軸無偏移
            //g.DrawLine(pen, 10, (float)(height / 2 - (width / 2) * Math.Sin(5 * Math.PI / 180)), (width - 10), (float)(height / 2 - (width / 2) * Math.Sin(5 * Math.PI / 180)));
            //g.DrawLine(pen, (float)(width / 2 + (height / 2) * Math.Sin(20 * Math.PI / 180)), 10, (float)(width / 2 - (height / 2) * Math.Sin(20 * Math.PI / 180)), (height - 10));
        }
        //剩下draw、closeprofile
    }

    public class Temp : Data
    {
        public double Temperature;
        public double Temp_count;
        public Temp(double temp)
        { 
            this.Temperature = temp;
        }

        //不用draw
    }

    public class Display
    {
        private Graphics g;
        public List<object> Entity = new List<object>();

        public Display(Graphics gIn)
        { 
            g = gIn;
        }

        public Errorcodes SaveData(string line) 
        {
            String[] Piecewise;
            String[] Piecewise_count;
            
            double Count;
            Section section = Section.INIT;

            if (line.ToUpper().Contains("ACCELERATION"))
            {
                section = Section.ACC;
                
            }
            else if (line.ToUpper().Contains("GYROSCOPE"))
            {
                section = Section.GY;
                
            }
            else if (line.ToUpper().Contains("TEMPERATURE"))
            {
                section = Section.TEMP;
                
            }
            int x = 0;
            switch (section)
            {
                case Section.ACC:
                    if (line.ToUpper().Contains("X,Y,Z"))
                    {
                        Piecewise = line.Trim().Split(':');
                        Piecewise_count = Piecewise[0].Trim().Split(')');
                        Count = Convert.ToDouble(Piecewise_count[0]);
                        Piecewise = Piecewise[1].Trim().Split(' ');
                        Entity.Add(new Acc( Convert.ToDouble(Piecewise[0]), Convert.ToDouble(Piecewise[1]), Convert.ToDouble(Piecewise[2]) ) );
                        
                    }
                    break;

                case Section.GY:
                    if (line.Contains("degrees/s"))
                    {
                        Piecewise = line.Trim().Split(':');
                        Piecewise_count = Piecewise[0].Trim().Split(')');
                        Count = Convert.ToDouble(Piecewise_count[0]);
                        Piecewise = Piecewise[1].Trim().Split(' ');
                        Entity.Add( new Gy( Convert.ToDouble(Piecewise[0]), Convert.ToDouble(Piecewise[1]), Convert.ToDouble(Piecewise[2]), g));
                        
                    }
                    break;


                case Section.TEMP:
                    if (line.ToUpper().Contains("HERE"))
                    {
                        Piecewise = line.Trim().Split(':');
                        Piecewise_count = Piecewise[0].Trim().Split(')');
                        Count = Convert.ToDouble(Piecewise_count[0]);
                        Entity.Add( new Temp( Convert.ToDouble(Piecewise[1])) );
                        
                    }
                    break;
            }


            return Errorcodes.NONE;
        }
        
    }

}
