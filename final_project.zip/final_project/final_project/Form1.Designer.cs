﻿namespace final_project
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.comboBox_rate = new System.Windows.Forms.ComboBox();
            this.button_com = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_drawing = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_acc = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_z = new System.Windows.Forms.Label();
            this.label_com = new System.Windows.Forms.Label();
            this.button_getvalue = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBox_rate
            // 
            this.comboBox_rate.FormattingEnabled = true;
            this.comboBox_rate.Location = new System.Drawing.Point(203, 60);
            this.comboBox_rate.Name = "comboBox_rate";
            this.comboBox_rate.Size = new System.Drawing.Size(202, 23);
            this.comboBox_rate.TabIndex = 0;
            this.comboBox_rate.SelectedIndexChanged += new System.EventHandler(this.comboBox_rate_SelectedIndexChanged);
            // 
            // button_com
            // 
            this.button_com.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_com.Location = new System.Drawing.Point(30, 178);
            this.button_com.Name = "button_com";
            this.button_com.Size = new System.Drawing.Size(134, 42);
            this.button_com.TabIndex = 1;
            this.button_com.Text = "連線";
            this.button_com.UseVisualStyleBackColor = true;
            this.button_com.Click += new System.EventHandler(this.button_com_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(75, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // button_drawing
            // 
            this.button_drawing.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_drawing.Location = new System.Drawing.Point(30, 315);
            this.button_drawing.Name = "button_drawing";
            this.button_drawing.Size = new System.Drawing.Size(134, 52);
            this.button_drawing.TabIndex = 3;
            this.button_drawing.Text = "畫圖";
            this.button_drawing.UseVisualStyleBackColor = true;
            this.button_drawing.Click += new System.EventHandler(this.button_drawing_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(527, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(486, 298);
            this.panel1.TabIndex = 4;
            // 
            // label_acc
            // 
            this.label_acc.AutoSize = true;
            this.label_acc.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_acc.Location = new System.Drawing.Point(308, 146);
            this.label_acc.Name = "label_acc";
            this.label_acc.Size = new System.Drawing.Size(148, 23);
            this.label_acc.TabIndex = 5;
            this.label_acc.Text = "三軸加速度值";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(308, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 23);
            this.label2.TabIndex = 6;
            this.label2.Text = "acc_x : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(308, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "acc_y : ";
            // 
            // label_z
            // 
            this.label_z.AutoSize = true;
            this.label_z.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_z.Location = new System.Drawing.Point(308, 296);
            this.label_z.Name = "label_z";
            this.label_z.Size = new System.Drawing.Size(79, 23);
            this.label_z.TabIndex = 8;
            this.label_z.Text = "acc_z : ";
            // 
            // label_com
            // 
            this.label_com.AutoSize = true;
            this.label_com.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_com.Location = new System.Drawing.Point(67, 60);
            this.label_com.Name = "label_com";
            this.label_com.Size = new System.Drawing.Size(97, 23);
            this.label_com.TabIndex = 9;
            this.label_com.Text = "序列埠 : ";
            // 
            // button_getvalue
            // 
            this.button_getvalue.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_getvalue.Location = new System.Drawing.Point(30, 246);
            this.button_getvalue.Name = "button_getvalue";
            this.button_getvalue.Size = new System.Drawing.Size(134, 42);
            this.button_getvalue.TabIndex = 10;
            this.button_getvalue.Text = "取值";
            this.button_getvalue.UseVisualStyleBackColor = true;
            this.button_getvalue.Click += new System.EventHandler(this.button_getvalue_Click);
            // 
            // button_logout
            // 
            this.button_logout.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_logout.Location = new System.Drawing.Point(31, 395);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(133, 48);
            this.button_logout.TabIndex = 11;
            this.button_logout.Text = "離開";
            this.button_logout.UseVisualStyleBackColor = true;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // button_stop
            // 
            this.button_stop.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_stop.Location = new System.Drawing.Point(184, 246);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(103, 42);
            this.button_stop.TabIndex = 12;
            this.button_stop.Text = "暫停";
            this.button_stop.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1144, 476);
            this.Controls.Add(this.button_stop);
            this.Controls.Add(this.button_logout);
            this.Controls.Add(this.button_getvalue);
            this.Controls.Add(this.label_com);
            this.Controls.Add(this.label_z);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_acc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_drawing);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_com);
            this.Controls.Add(this.comboBox_rate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ComboBox comboBox_rate;
        private System.Windows.Forms.Button button_com;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_drawing;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_acc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_z;
        private System.Windows.Forms.Label label_com;
        private System.Windows.Forms.Button button_getvalue;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Button button_stop;
    }
}

