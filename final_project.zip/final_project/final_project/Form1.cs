﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace final_project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.BaudRate = 9600;    //這個之後要再調整
            serialPort1.Parity = Parity.None;
            serialPort1.StopBits = StopBits.One;
            serialPort1.DataBits = 8;
            comboBox_rate.Items.AddRange(SerialPort.GetPortNames());
            label1.Text = "尚未連線 QQ";
            button_getvalue.Enabled = false;
            button_drawing.Enabled = false;
            button_logout.Enabled = false;
        }

        private void comboBox_rate_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = comboBox_rate.Text;
        }

        private void button_com_Click(object sender, EventArgs e)
        {
            serialPort1.Open();
            button_com.Enabled = false;
            label1.Text = "已經連線中";
            button_com.Enabled = false;
            button_drawing.Enabled = true;
            button_getvalue.Enabled = true;
            button_logout.Enabled = true;
        }

        private void button_getvalue_Click(object sender, EventArgs e)
        {
            serialPort1.DtrEnable = true;   //不確定需不需要
            serialPort1.RtsEnable = true;   //不確定需不需要
            //https://www.cnblogs.com/luguangguang/p/8257165.html
            /*
             假設ardunio的serial println所發布的值為
            acc_x : 0.555 , acc_y : 0.555 , acc_z : 0.555
            acc_x : 0.456 , acc_y : 0.123 , acc_z : 0.789
             */


            while (true)
            { 
                string input_data = serialPort1.ReadLine();
                if (input_data == null) return;
                //開始切分input_data，跟作業7那邊差不多
            }
        }

        private void button_logout_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            button_com.Enabled = true;
            button_drawing.Enabled = false;
            button_getvalue.Enabled = false;
            label1.Text = "斷線中";
        }

        private void button_drawing_Click(object sender, EventArgs e)
        {
            //畫圖
        }
    }
}
