﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _107303528_HW5_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public enum FileTypes
        {
            EMPTY = 1,
            SOLID = 2
        }

        public enum SectionTypes
        {
            UNKNOWN_SECTION = -1,
            DRAWING_TASK,
            GENERAL_INFORMATION,
            GEOMETRIC_ENTITY
        }

        public enum ErrorCodes
        {
            NONE = 0,
            WRONG_FILE_FORMAT_VERSION = 1,
            TOO_MANY_ENTITIES = 2
        }
        public struct Line          //Line
        {
            public Point StartPt;
            public Point EndPt;
            public Line(Point startPt, Point endPt)
            {
                this.StartPt = startPt;
                this.EndPt = endPt;
            }
        }


        public struct Circle        //circle
        {
            public Point CenPt;
            public int Radius;
            public FileTypes FileType;
            public Circle(Point cenPt, int radius, FileTypes fileType)
            {
                this.CenPt = cenPt;
                this.Radius = radius;
                this.FileType = fileType;
            }
        }


        public struct Arc
        {
            public Point CenPt;
            public int Radius;
            public int StartAngle;
            public int EndAngle;

            public Arc(Point cenPt, int radius, int startAngle, int endAngle)
            {
                this.CenPt = cenPt;
                this.Radius = radius;
                this.StartAngle = startAngle;
                this.EndAngle = endAngle;
            }
        }


        public struct Ellipse        //circle
        {
            public Point CenPt;
            public int Long_axis;
            public int Short_axis;
            public FileTypes FileType;
            public Ellipse(Point cenPt, int long_axis, int short_axis, FileTypes fileType)
            {
                this.CenPt = cenPt;
                this.Long_axis = long_axis;
                this.Short_axis = short_axis;
                this.FileType = fileType;
            }
        }
        private ErrorCodes LoadTaskFile(String Filename)
        {
            
            int Version = -1;
            
            String CurLine;
            String[] Piecewise;
            SectionTypes Section = SectionTypes.UNKNOWN_SECTION;
                                
            StreamReader TaskText = new StreamReader(openFileDialog.FileName);
            while (TaskText.Peek() >= 0)
            {
                CurLine = TaskText.ReadLine();
                if (CurLine.ToUpper().Contains("DRAWING TASK"))
                {
                    Section = SectionTypes.DRAWING_TASK;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GENERAL INFORMATION"))
                {
                    Section = SectionTypes.GENERAL_INFORMATION;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GEOMETRIC ENTITY"))
                {
                    Section = SectionTypes.GEOMETRIC_ENTITY;
                    continue;
                }

                switch (Section)
                {
                    case SectionTypes.DRAWING_TASK:     //DRAWING TASK
                        if (CurLine.ToUpper().Contains("FORMAT VERSION"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Version = Convert.ToInt32(Piecewise[1]);
                            if (Version != CURRENT_VALUE)
                            {
                                return ErrorCodes.WRONG_FILE_FORMAT_VERSION;
                            }
                        }
                        break;

                    case SectionTypes.GENERAL_INFORMATION:     //GENERAL INFORMATION
                        if (CurLine.ToUpper().Contains("LINE WIDTH"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            LineWidth = Convert.ToInt32(Piecewise[1]);
                        }
                        break;

                    case SectionTypes.GEOMETRIC_ENTITY:     //GEOMETRIC ENTITY
                        if (CurLine.ToUpper().Contains("LINE"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            DLine[TotalLineNum++] = new Line(new Point(Convert.ToInt32(Piecewise[0]),
                                                                    Convert.ToInt32(Piecewise[1])),
                                                           new Point(Convert.ToInt32(Piecewise[2]),
                                                                    Convert.ToInt32(Piecewise[3])));

                            
                        }
                        else if (CurLine.ToUpper().Contains("CIRCLE"))
                        {
                            FileTypes CFileType;
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            CFileType = (Piecewise[3].ToUpper().Contains("SOLID")) ? FileTypes.SOLID : FileTypes.EMPTY;
                            DCircle[TotalCircleNum++] = new Circle(new Point(Convert.ToInt32(Piecewise[0]),
                                                                             Convert.ToInt32(Piecewise[1])),
                                                                            (Convert.ToInt32(Piecewise[2])),
                                                                             CFileType);
                            

                        }
                        else if (CurLine.ToUpper().Contains("ARC"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            DArc[TotalArcNum++] = new Arc(new Point(Convert.ToInt32(Piecewise[0]),
                                                                     Convert.ToInt32(Piecewise[1])),
                                                                    (Convert.ToInt32(Piecewise[2])),
                                                                    (Convert.ToInt32(Piecewise[3])),
                                                                    (Convert.ToInt32(Piecewise[4])));
                            
                        }
                        else if (CurLine.ToUpper().Contains("ELLIPSE"))
                        {
                            FileTypes EFileType;
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            EFileType = (Piecewise[4].ToUpper().Contains("SOLID")) ? FileTypes.SOLID : FileTypes.EMPTY;
                            DEllipse[TotalEllipseNum++] = new Ellipse(new Point(Convert.ToInt32(Piecewise[0]),
                                                                                Convert.ToInt32(Piecewise[1])),
                                                                               (Convert.ToInt32(Piecewise[2])),
                                                                               (Convert.ToInt32(Piecewise[3])),
                                                                               EFileType);
                        }

                        break;
                }
   
                if (TotalLineNum > MAX_ENTITY_NUMBER || TotalCircleNum > MAX_ENTITY_NUMBER || TotalArcNum > MAX_ENTITY_NUMBER || TotalEllipseNum > MAX_ENTITY_NUMBER)
                {
                    return ErrorCodes.TOO_MANY_ENTITIES;
                }
            }
            return ErrorCodes.NONE;
        }
        private void button_load_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ErrorCodes CurErrCode =  LoadTaskFile(openFileDialog.FileName);

                switch (CurErrCode)
                {
                    case ErrorCodes.WRONG_FILE_FORMAT_VERSION:
                        MessageBox.Show("");
                        break;
                    case ErrorCodes.TOO_MANY_ENTITIES:
                        MessageBox.Show("");
                        break;
                    case ErrorCodes.NONE:
                        listBox_line.Items.Clear();
                        for (int i = 0; i < TotalLineNum; i++)
                        {
                            listBox_line.Items.Add("( " + DLine[i].StartPt.X + ", " + DLine[i].StartPt.Y + " ) to ( " + DLine[i].EndPt.X + ", " + DLine[i].EndPt.Y + " )");
                        }
                        listBox_circle.Items.Clear();
                        for (int i = 0; i < TotalCircleNum; i++)
                        {
                            listBox_circle.Items.Add("( " + DCircle[i].CenPt.X + ", " + DCircle[i].CenPt.Y + " ) R ( " + DCircle[i].Radius + " )" + "  ( " + DCircle[i].FileType + "  )");
                        }
                        listBox_arc.Items.Clear();
                        for (int i = 0; i < TotalArcNum; i++)
                        {
                            listBox_arc.Items.Add("( " + DArc[i].CenPt.X + ", " + DArc[i].CenPt.Y + " ) R ( " + DArc[i].Radius + " )   " + " Start :   " + DArc[i].StartAngle + ",   End :   " + DArc[i].EndAngle);
                        }
                        for (int i = 0; i < TotalEllipseNum; i++)
                        {
                            listBox_ellipse.Items.Add("( " + DEllipse[i].CenPt.X + ", " + DEllipse[i].CenPt.Y + " )   " + "Major axis :  " + DEllipse[i].Long_axis + ",   Minor axis :   " + DEllipse[i].Short_axis + "  (" + DEllipse[i].FileType + "  )" );
                        }
                        break;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DLine = new Line[MAX_ENTITY_NUMBER];
            TotalLineNum = 0;
            DCircle = new Circle[MAX_ENTITY_NUMBER];
            TotalCircleNum = 0;
            DArc = new Arc[MAX_ENTITY_NUMBER];
            DEllipse = new Ellipse[MAX_ENTITY_NUMBER];
            LineWidth = -1;
            openFileDialog.Filter = "Task Files (*.tsk)|*.tsk|All Files(*.*)|*.*";
            openFileDialog.FileName = "";
            openFileDialog.Title = "Open a Task,please!";

            DirectoryInfo ProjectDir = new DirectoryInfo(Application.StartupPath);
            openFileDialog.InitialDirectory = ProjectDir.Parent.Parent.FullName;

            g = this.paneldrawing.CreateGraphics();
        }

        private void paneldrawing_Paint(object sender, PaintEventArgs e)
        {
            //當畫面有需要更新後留在畫面之中的時候，都要在paint的事件中執行
            //考試可能會考
            Pen pen = new Pen(Color.Red, LineWidth);
            SolidBrush BlueBrush = new SolidBrush(Color.Blue);

            
            

            for (int i = 0; i < listBox_line.SelectedIndices.Count; i++)
            {
                g.DrawLine(pen, DLine[listBox_line.SelectedIndices[i]].StartPt,
                                DLine[listBox_line.SelectedIndices[i]].EndPt);
            }

          
            
            
            for (int i = 0; i < listBox_circle.SelectedIndices.Count; i++)
            {

                if (DCircle[listBox_circle.SelectedIndices[i]].FileType == FileTypes.EMPTY)
                {
                    g.DrawEllipse(pen, DCircle[listBox_circle.SelectedIndices[i]].CenPt.X -
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                                 DCircle[listBox_circle.SelectedIndices[i]].CenPt.Y -
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius * 2,
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius * 2);
                }
                else
                {
                    g.FillEllipse(BlueBrush, DCircle[listBox_circle.SelectedIndices[i]].CenPt.X -
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                           DCircle[listBox_circle.SelectedIndices[i]].CenPt.Y -
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius * 2,
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius * 2);
                }
                /*
                switch (DCircle[listBox_circle.SelectedIndices[i]].FileType)
                {
                    case FileTypes.EMPTY:
                        g.DrawEllipse(pen, DCircle[listBox_circle.SelectedIndices[i]].CenPt.X -
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                           DCircle[listBox_circle.SelectedIndices[i]].CenPt.Y -
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius * 2,
                                           DCircle[listBox_circle.SelectedIndices[i]].Radius * 2);
                        break;

                    case FileTypes.SOLID:
                        g.FillEllipse(BlueBrush, DCircle[listBox_circle.SelectedIndices[i]].CenPt.X -
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                                 DCircle[listBox_circle.SelectedIndices[i]].CenPt.Y -
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius,
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius * 2,
                                                 DCircle[listBox_circle.SelectedIndices[i]].Radius * 2);
                        break;
                }
                */
                
            
            }
            for (int i = 0; i < listBox_arc.SelectedIndices.Count; i++)
            {
                g.DrawArc(pen, DArc[listBox_arc.SelectedIndices[i]].CenPt.X,
                               DArc[listBox_arc.SelectedIndices[i]].CenPt.Y,
                               DArc[listBox_arc.SelectedIndices[i]].Radius,
                               DArc[listBox_arc.SelectedIndices[i]].Radius,
                               DArc[listBox_arc.SelectedIndices[i]].StartAngle,
                               DArc[listBox_arc.SelectedIndices[i]].EndAngle);

            }
            for (int i = 0; i < listBox_ellipse.SelectedIndices.Count; i++)
            {
                switch (DEllipse[listBox_ellipse.SelectedIndices[i]].FileType)
                {
                    case FileTypes.EMPTY:
                        g.DrawEllipse(pen, DEllipse[listBox_ellipse.SelectedIndices[i]].CenPt.X,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].CenPt.Y,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].Long_axis,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].Short_axis);
                        break;

                    case FileTypes.SOLID:
                        g.FillEllipse(BlueBrush, DEllipse[listBox_ellipse.SelectedIndices[i]].CenPt.X,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].CenPt.Y,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].Long_axis,
                                           DEllipse[listBox_ellipse.SelectedIndices[i]].Short_axis);
                        break;
                }
                

            }
        }

        private void listBox_line_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        private void listBox_circle_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        private void label_circle_Click(object sender, EventArgs e)
        {

        }

        private void label_line_Click(object sender, EventArgs e)
        {

        }

        private void listBox_arc_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        private void listBox_ellipse_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }
    }
}
