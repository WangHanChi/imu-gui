﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace _107303528_HW2_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            input_num.Text = DefaultMaxNum.ToString();
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            double MaxNumDouble = Convert.ToDouble(input_num.Text); 
            Stopwatch sw = new Stopwatch();
            sw.Reset();
            sw.Start();
            for (double i = 0.0; i < MaxNumDouble; i = i + 1.0) ;
            sw.Stop();
            label_double.Text = sw.Elapsed.TotalMilliseconds.ToString("0.000") + "ms";
            double double_time = sw.Elapsed.TotalMilliseconds;

            Decimal MaxNumDecimal = Convert.ToDecimal(input_num.Text);
            sw.Reset();
            sw.Start();
            for (Decimal i = 0.0M; i < MaxNumDecimal; i = i + 1) ;
            sw.Stop();
            label_Decimal.Text = sw.Elapsed.TotalMilliseconds.ToString("0.000") + "ms";

            double Decimal_time = sw.Elapsed.TotalMilliseconds;

            if (double_time > Decimal_time)
            {
                Decimal_arrow.Visible = true;
            }
            else if (double_time < Decimal_time)
            {
                double_arrow.Visible = true;
            }
            else if (double_time == Decimal_time)
            {
                Decimal_arrow.Visible = true;
                double_arrow.Visible = true;
            }


        }
    }
}
