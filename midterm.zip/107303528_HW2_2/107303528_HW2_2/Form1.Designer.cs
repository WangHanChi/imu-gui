﻿namespace _107303528_HW2_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private int DefaultMaxNum = 1000000;    
        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.input_num = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.diet = new System.Windows.Forms.PictureBox();
            this.button_start = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.double_arrow = new System.Windows.Forms.PictureBox();
            this.Decimal_arrow = new System.Windows.Forms.PictureBox();
            this.label_double = new System.Windows.Forms.Label();
            this.label_Decimal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.diet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.double_arrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Decimal_arrow)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(239, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Count from 1 to";
            // 
            // input_num
            // 
            this.input_num.Location = new System.Drawing.Point(400, 102);
            this.input_num.Name = "input_num";
            this.input_num.Size = new System.Drawing.Size(100, 22);
            this.input_num.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(523, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = ".";
            // 
            // diet
            // 
            this.diet.Image = global::_107303528_HW2_2.Properties.Resources.Win_Lose;
            this.diet.Location = new System.Drawing.Point(362, 263);
            this.diet.Name = "diet";
            this.diet.Size = new System.Drawing.Size(300, 241);
            this.diet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.diet.TabIndex = 3;
            this.diet.TabStop = false;
            // 
            // button_start
            // 
            this.button_start.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_start.ForeColor = System.Drawing.Color.Fuchsia;
            this.button_start.Location = new System.Drawing.Point(696, 80);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(118, 64);
            this.button_start.TabIndex = 4;
            this.button_start.Text = "Start";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(135, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 48);
            this.label3.TabIndex = 5;
            this.label3.Text = "Decimal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(731, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 48);
            this.label4.TabIndex = 6;
            this.label4.Text = "Double";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // double_arrow
            // 
            this.double_arrow.Image = ((System.Drawing.Image)(resources.GetObject("double_arrow.Image")));
            this.double_arrow.Location = new System.Drawing.Point(714, 381);
            this.double_arrow.Name = "double_arrow";
            this.double_arrow.Size = new System.Drawing.Size(100, 57);
            this.double_arrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.double_arrow.TabIndex = 7;
            this.double_arrow.TabStop = false;
            this.double_arrow.Visible = false;
            // 
            // Decimal_arrow
            // 
            this.Decimal_arrow.Image = ((System.Drawing.Image)(resources.GetObject("Decimal_arrow.Image")));
            this.Decimal_arrow.Location = new System.Drawing.Point(224, 388);
            this.Decimal_arrow.Name = "Decimal_arrow";
            this.Decimal_arrow.Size = new System.Drawing.Size(100, 50);
            this.Decimal_arrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Decimal_arrow.TabIndex = 8;
            this.Decimal_arrow.TabStop = false;
            this.Decimal_arrow.Visible = false;
            // 
            // label_double
            // 
            this.label_double.AutoSize = true;
            this.label_double.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_double.ForeColor = System.Drawing.Color.Blue;
            this.label_double.Location = new System.Drawing.Point(852, 398);
            this.label_double.Name = "label_double";
            this.label_double.Size = new System.Drawing.Size(57, 24);
            this.label_double.TabIndex = 9;
            this.label_double.Text = "??ms";
            // 
            // label_Decimal
            // 
            this.label_Decimal.AutoSize = true;
            this.label_Decimal.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Decimal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Decimal.Location = new System.Drawing.Point(121, 398);
            this.label_Decimal.Name = "label_Decimal";
            this.label_Decimal.Size = new System.Drawing.Size(57, 24);
            this.label_Decimal.TabIndex = 10;
            this.label_Decimal.Text = "??ms";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 599);
            this.Controls.Add(this.label_Decimal);
            this.Controls.Add(this.label_double);
            this.Controls.Add(this.Decimal_arrow);
            this.Controls.Add(this.double_arrow);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.diet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.input_num);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.diet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.double_arrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Decimal_arrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox input_num;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox diet;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox double_arrow;
        private System.Windows.Forms.PictureBox Decimal_arrow;
        private System.Windows.Forms.Label label_double;
        private System.Windows.Forms.Label label_Decimal;
    }
}

