﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW3_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = this.CreateGraphics();
            formColor = Color.LightPink;
            clickPoint = new Point[99];
            PointCounter = 0;
            clickPoint_right = new Point[99];
            PointCounter_right = 0;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            g.Clear(formColor);
            SolidBrush brush = new SolidBrush(Color.Blue);
            Font font = new Font("Georgia", 24);
            g.DrawString("Hello!!!!!!", font, brush, 20, 20);
            Pen pen = new Pen(Color.Red, 5);
            for(int i = 0; i< PointCounter; i = i + 2)
            {
                g.DrawLine(pen, clickPoint[i], clickPoint[i + 1]);
            }
            Pen pen2 = new Pen(Color.Green, 5);
           
            for (int i = 0; i < PointCounter_right; i = i + 2)
            {
                g.DrawRectangle(pen2,100, 100, 100, 100);
            }


        }

        private void Form1_Click(object sender, EventArgs e)
        {
            //SolidBrush brush = new SolidBrush(Color.Blue);
            //Font font = new Font("Georgia", 24);
            //g.DrawString("Hello!!!!!!", font, brush, 20, 20);
            //這個操作無效，因為他在recover的時候只會去抓paint事件的內容
            //因此最好的做法就是把要畫的東西放在paint 事件之中
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {

            //g.Clear(Color.Blue);
            //此操作只會執行一次，他不會自動觸發，所以放在paint是最好的做法
            //考試可能會考，比較好的最法式再多宣告一個參數，如下面所示
            formColor = Color.Blue;
            Refresh();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                clickPoint[PointCounter] = new Point(e.X, e.Y);
                PointCounter++;
            }
            else if (e.Button == MouseButtons.Right)
            {
                clickPoint_right[PointCounter] = new Point(e.X, e.Y);
                PointCounter_right++;
            }

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                clickPoint[PointCounter] = new Point(e.X, e.Y);
                PointCounter++;
                Refresh();
            }
            else if (e.Button == MouseButtons.Right)
            {
                clickPoint_right[PointCounter] = new Point(e.X, e.Y);
                PointCounter_right++;
                Refresh();
            }
        }
    }
}
