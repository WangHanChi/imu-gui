﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW4_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox_car.Location = new Point((this.ClientSize.Width - pictureBox_car.Width) / 2,
                                                (this.ClientSize.Height - pictureBox_car.Height) / 2);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int Step = 10;



            if (e.Alt)
                Step =20;
            else if (e.Control)
                Step = 5;
            switch (e.KeyCode)
            {
                case Keys.Up:
                    pictureBox_car.Top -= Step;
                    break;

                case Keys.Down:
                    pictureBox_car.Top += Step;
                    break;
                case Keys.Right:
                    pictureBox_car.Left += Step;
                    break;
                case Keys.Left:
                    pictureBox_car.Left -= Step;
                    break;
            }

            if (e.KeyCode == Keys.Up)
            {

            } 
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            pictureBox_car.Location = new Point((this.ClientSize.Width - pictureBox_car.Width) / 2,
                                                (this.ClientSize.Height - pictureBox_car.Height) / 2);
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case 'G':
                case 'g':
                    this.BackColor = Color.Green;
                    break;

                case 'B':
                case 'b':
                    this.BackColor = Color.Blue;
                    break;

                case 'R':
                case 'r':
                    this.BackColor = Color.Red;
                    break;
            }
        }
    }
}
