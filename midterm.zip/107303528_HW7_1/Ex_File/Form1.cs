﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Ex_File
{
    public partial class Form1 : Form
    {
        public enum FillTypes
        {
            EMPTY = 1,
            SOLID = 2
        }

        public enum SectionTypes
        {
            UNKNOWN_SECTION = -1,
            DRAWING_TASK,
            GENERAL_INFORMATION,
            GEOMETRIC_ENTITY
        }

        public enum ErrorCodes
        {
            NONE = 0,
            WRONG_FILE_FORMAT_VERSION = 1,
            TOO_MANY_ENTITIES = 2
        }

        public struct Line
        {
            public Point StartPt;
            public Point EndPt;

            public Line(Point startPt, Point endPt)
            {
                this.StartPt = startPt;
                this.EndPt = endPt;
            }
        }
        
        public struct Circle
        {
            public Point CenPt;
            public int Radius;
            public FillTypes FillType;

            public Circle(Point cenPt, int radius, FillTypes fillType)
            {
                this.CenPt = cenPt;
                this.Radius = radius;
                this.FillType = fillType;
            }
        }

        public struct Arc
        {
            public Point CenPt;
            public int Radius;
            public int StartAngle;
            public int EndAngle;

            public Arc(Point cenPt, int radius, int startAngle, int endAngle)
            {
                this.CenPt = cenPt;
                this.Radius = radius;
                this.StartAngle = startAngle;
                this.EndAngle = endAngle;
            }
        }

        public struct Ellipse
        {
            public Point CenPt;
            public int MajorAxis;
            public int MinorAxis;
            public FillTypes FillType;

            public Ellipse(Point cenPt, int majorAxis, int minorAxis, FillTypes fillType)
            {
                this.CenPt = cenPt;
                this.MajorAxis = majorAxis;
                this.MinorAxis = minorAxis;
                this.FillType = fillType;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private ErrorCodes LoadTaskFile(String FileName)
        {
            int Version = CURRENT_VERSION;
            String CurLine;
            StreamReader TaskText = new StreamReader(FileName);
            String[] Piecewise;
            SectionTypes Section = SectionTypes.UNKNOWN_SECTION;

            while (TaskText.Peek() >= 0)
            {
                CurLine = TaskText.ReadLine();

                if (CurLine.ToUpper().Contains("DRAWING TASK"))
                {
                    Section = SectionTypes.DRAWING_TASK;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GENERAL INFORMATION"))
                {
                    Section = SectionTypes.GENERAL_INFORMATION;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GEOMETRIC ENTITY"))
                {
                    Section = SectionTypes.GEOMETRIC_ENTITY;
                    continue;
                }

                switch (Section)
                {
                    case SectionTypes.DRAWING_TASK:
                        if (CurLine.ToUpper().Contains("FORMAT VERSION"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Version = Convert.ToInt32(Piecewise[1]);
                            if (Version != CURRENT_VERSION)
                                return ErrorCodes.WRONG_FILE_FORMAT_VERSION;
                        }
                        break;
                    case SectionTypes.GENERAL_INFORMATION:
                        if (CurLine.ToUpper().Contains("LINE WIDTH"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            LineWidth = Convert.ToInt32(Piecewise[1]);
                        }
                        break;
                    case SectionTypes.GEOMETRIC_ENTITY:
                        if (CurLine.ToUpper().Contains("LINE"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            Entity[TotalEntityNum] = new Line(new Point(Convert.ToInt32(Piecewise[0]), Convert.ToInt32(Piecewise[1])), new Point(Convert.ToInt32(Piecewise[2]), Convert.ToInt32(Piecewise[3])));   
                            TotalEntityNum++;   //++也可以放在上面
                        }
                        else if (CurLine.ToUpper().Contains("CIRCLE"))
                        {   
                            FillTypes CFillType;

                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            CFillType = (Piecewise[3].ToUpper().Contains("SOLID")) ? FillTypes.SOLID :  FillTypes.EMPTY;
                            Entity[TotalEntityNum] = new Circle(new Point(Convert.ToInt32(Piecewise[0]), Convert.ToInt32(Piecewise[1])), Convert.ToInt32(Piecewise[2]), CFillType);
                            TotalEntityNum++;
                        }
                        else if (CurLine.ToUpper().Contains("ARC"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            Entity[TotalEntityNum] = new Arc(new Point(Convert.ToInt32(Piecewise[0]), Convert.ToInt32(Piecewise[1])), Convert.ToInt32(Piecewise[2]), Convert.ToInt32(Piecewise[3]), Convert.ToInt32(Piecewise[4]));
                            TotalEntityNum++;
                        }
                        else if (CurLine.ToUpper().Contains("ELLIPSE"))
                        {
                            FillTypes EFillType;

                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            EFillType = (Piecewise[4].ToUpper().Contains("SOLID")) ? FillTypes.SOLID : FillTypes.EMPTY;
                            Entity[TotalEntityNum] = new Ellipse(new Point(Convert.ToInt32(Piecewise[0]), Convert.ToInt32(Piecewise[1])), Convert.ToInt32(Piecewise[2]), Convert.ToInt32(Piecewise[3]), EFillType);
                            TotalEntityNum++;
                        }
                        break;
                }
                if (TotalEntityNum > MAX_ENTITY_NUMBER )
                    return ErrorCodes.TOO_MANY_ENTITIES;   
            }  
            return ErrorCodes.NONE;
        }

        private void button_Load_Click(object sender, EventArgs e)
        {
            if (openFileDialog_Load.ShowDialog() == DialogResult.OK)
            {
                ErrorCodes CurErrCode = LoadTaskFile(openFileDialog_Load.FileName);
                switch (CurErrCode)
                {
                    case ErrorCodes.WRONG_FILE_FORMAT_VERSION:
                        MessageBox.Show("Wrong Version!!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    case ErrorCodes.TOO_MANY_ENTITIES:
                        MessageBox.Show("Too Many Entities in Drawing Task File!!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    case ErrorCodes.NONE:
                        for (int i = 0; i < TotalEntityNum; i++)
                        {

                            //boxing and unboxing
                            if (Entity[i].GetType() == typeof(Line))
                            {
                                Line CurrentLine = (Line)Entity[i];
                                listBox_Entity.Items.Add("(" + CurrentLine.StartPt.X + ", " + CurrentLine.StartPt.Y + ") to (" + CurrentLine.EndPt.X + ", " + CurrentLine.EndPt.Y + ")");
                            }
                            else if (Entity[i].GetType() == typeof(Circle))
                            {
                                Circle CurrentCircle = (Circle)Entity[i];
                                listBox_Entity.Items.Add("(" + CurrentCircle.CenPt.X + ", " + CurrentCircle.CenPt.Y + ") R" + CurrentCircle.Radius + ((CurrentCircle.FillType == FillTypes.EMPTY) ? " Empty" : " Solid"));
                            }
                            else if (Entity[i].GetType() == typeof(Arc))
                            {
                                Arc CurrentArc = (Arc)Entity[i];
                                listBox_Entity.Items.Add("(" + CurrentArc.CenPt.X + ", " + CurrentArc.CenPt.Y + ") R" + CurrentArc.Radius + " S" + CurrentArc.StartAngle + " E" + CurrentArc.EndAngle);
                            }
                            else if (Entity[i].GetType() == typeof(Ellipse))
                            {
                                Ellipse CurrentEllipse = (Ellipse)Entity[i];
                                listBox_Entity.Items.Add("(" + CurrentEllipse.CenPt.X + ", " + CurrentEllipse.CenPt.Y + ") A" + CurrentEllipse.MajorAxis + " B" + CurrentEllipse.MinorAxis + ((CurrentEllipse.FillType == FillTypes.EMPTY) ? " Empty" : " Solid"));
                            }
                        }
                            
                        break;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LineWidth = 0;
            TotalEntityNum = 0;

            Entity = new Object[MAX_ENTITY_NUMBER];

            DirectoryInfo ProjectDir = new DirectoryInfo(System.Windows.Forms.Application.StartupPath);
            openFileDialog_Load.InitialDirectory = ProjectDir.Parent.Parent.FullName;
            g = this.panel_Drawing.CreateGraphics();
        }

        private void panel_Drawing_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Red, LineWidth);
            SolidBrush brush = new SolidBrush(Color.Red);
            g.Clear(this.BackColor);
            for (int i = 0; i < listBox_Entity.SelectedIndices.Count; i++)
            {
                Object CurrentEntity = Entity[listBox_Entity.SelectedIndices[i]];
                if (CurrentEntity.GetType() == typeof(Line))
                {
                    Line CurrentLine = (Line)CurrentEntity;
                    g.DrawLine(pen, CurrentLine.StartPt, CurrentLine.EndPt);
                }
                else if (CurrentEntity.GetType() == typeof(Circle))
                {
                    Circle CurrentCircle = (Circle)CurrentEntity;
                    if (CurrentCircle.FillType == FillTypes.SOLID)
                        g.FillEllipse(brush, CurrentCircle.CenPt.X - CurrentCircle.Radius, CurrentCircle.CenPt.Y - CurrentCircle.Radius, CurrentCircle.Radius * 2, CurrentCircle.Radius * 2);
                    else
                        g.DrawEllipse(pen, CurrentCircle.CenPt.X - CurrentCircle.Radius, CurrentCircle.CenPt.Y - CurrentCircle.Radius, CurrentCircle.Radius * 2, CurrentCircle.Radius * 2);
                }
                else if (CurrentEntity.GetType() == typeof(Arc))
                {
                    Arc CurrentArc = (Arc)CurrentEntity;
                    g.DrawArc(pen, CurrentArc.CenPt.X - CurrentArc.Radius, CurrentArc.CenPt.Y - CurrentArc.Radius, CurrentArc.Radius * 2, CurrentArc.Radius * 2, CurrentArc.StartAngle, CurrentArc.EndAngle - CurrentArc.StartAngle);
                }
                else if (CurrentEntity.GetType() == typeof(Ellipse))
                {
                    Ellipse CurrentEllipse = (Ellipse)CurrentEntity;
                    if (CurrentEllipse.FillType == FillTypes.SOLID)
                        g.FillEllipse(brush, CurrentEllipse.CenPt.X - CurrentEllipse.MajorAxis / 2, CurrentEllipse.CenPt.Y - CurrentEllipse.MinorAxis / 2, CurrentEllipse.MajorAxis, CurrentEllipse.MinorAxis);
                    else
                        g.DrawEllipse(pen, CurrentEllipse.CenPt.X - CurrentEllipse.MajorAxis / 2, CurrentEllipse.CenPt.Y - CurrentEllipse.MinorAxis / 2, CurrentEllipse.MajorAxis, CurrentEllipse.MinorAxis);
                }
            }
                
            
            
        }

        private void listBox_Line_SelectedIndexChanged(object sender, EventArgs e)
        {        
            Refresh();
        }

        private void listBox_Circle_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();     
        }

        private void listBox_Arc_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();        
        }

        private void listBox_Ellipse_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();            
        }
    }
}
