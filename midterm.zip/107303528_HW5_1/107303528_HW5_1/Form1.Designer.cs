﻿using System.Drawing;

namespace _107303528_HW5_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// 
        /// 
        /// 
        /// 
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        int[,] Line;
        int TotalLineNum;
        int[,] Circle;
        int TotalCircleNum;
        //0331
        int LineWidth;
        Graphics g;
        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_load = new System.Windows.Forms.Button();
            this.label_line = new System.Windows.Forms.Label();
            this.label_circle = new System.Windows.Forms.Label();
            this.label_drawings = new System.Windows.Forms.Label();
            this.listBox_line = new System.Windows.Forms.ListBox();
            this.listBox_circle = new System.Windows.Forms.ListBox();
            this.paneldrawing = new System.Windows.Forms.Panel();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // button_load
            // 
            this.button_load.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_load.Location = new System.Drawing.Point(133, 93);
            this.button_load.Name = "button_load";
            this.button_load.Size = new System.Drawing.Size(129, 67);
            this.button_load.TabIndex = 0;
            this.button_load.Text = "Load";
            this.button_load.UseVisualStyleBackColor = true;
            this.button_load.Click += new System.EventHandler(this.button_load_Click);
            // 
            // label_line
            // 
            this.label_line.AutoSize = true;
            this.label_line.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_line.Location = new System.Drawing.Point(341, 203);
            this.label_line.Name = "label_line";
            this.label_line.Size = new System.Drawing.Size(69, 24);
            this.label_line.TabIndex = 1;
            this.label_line.Text = "Line : ";
            // 
            // label_circle
            // 
            this.label_circle.AutoSize = true;
            this.label_circle.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_circle.Location = new System.Drawing.Point(341, 393);
            this.label_circle.Name = "label_circle";
            this.label_circle.Size = new System.Drawing.Size(83, 24);
            this.label_circle.TabIndex = 2;
            this.label_circle.Text = "Circle : ";
            // 
            // label_drawings
            // 
            this.label_drawings.AutoSize = true;
            this.label_drawings.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_drawings.Location = new System.Drawing.Point(809, 61);
            this.label_drawings.Name = "label_drawings";
            this.label_drawings.Size = new System.Drawing.Size(109, 24);
            this.label_drawings.TabIndex = 3;
            this.label_drawings.Text = "Drawings :";
            // 
            // listBox_line
            // 
            this.listBox_line.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox_line.FormattingEnabled = true;
            this.listBox_line.ItemHeight = 19;
            this.listBox_line.Location = new System.Drawing.Point(345, 256);
            this.listBox_line.Name = "listBox_line";
            this.listBox_line.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox_line.Size = new System.Drawing.Size(289, 99);
            this.listBox_line.TabIndex = 4;
            this.listBox_line.SelectedIndexChanged += new System.EventHandler(this.listBox_line_SelectedIndexChanged);
            // 
            // listBox_circle
            // 
            this.listBox_circle.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox_circle.FormattingEnabled = true;
            this.listBox_circle.ItemHeight = 19;
            this.listBox_circle.Location = new System.Drawing.Point(345, 451);
            this.listBox_circle.Name = "listBox_circle";
            this.listBox_circle.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox_circle.Size = new System.Drawing.Size(289, 99);
            this.listBox_circle.TabIndex = 5;
            this.listBox_circle.SelectedIndexChanged += new System.EventHandler(this.listBox_circle_SelectedIndexChanged);
            // 
            // paneldrawing
            // 
            this.paneldrawing.Location = new System.Drawing.Point(813, 93);
            this.paneldrawing.Name = "paneldrawing";
            this.paneldrawing.Size = new System.Drawing.Size(375, 402);
            this.paneldrawing.TabIndex = 6;
            this.paneldrawing.Paint += new System.Windows.Forms.PaintEventHandler(this.paneldrawing_Paint);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1258, 656);
            this.Controls.Add(this.paneldrawing);
            this.Controls.Add(this.listBox_circle);
            this.Controls.Add(this.listBox_line);
            this.Controls.Add(this.label_drawings);
            this.Controls.Add(this.label_circle);
            this.Controls.Add(this.label_line);
            this.Controls.Add(this.button_load);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_load;
        private System.Windows.Forms.Label label_line;
        private System.Windows.Forms.Label label_circle;
        private System.Windows.Forms.Label label_drawings;
        private System.Windows.Forms.ListBox listBox_line;
        private System.Windows.Forms.ListBox listBox_circle;
        private System.Windows.Forms.Panel paneldrawing;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}

