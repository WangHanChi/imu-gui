﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _107303528_HW5_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadTaskFile(String Filename)
        {
            int Version = -1;
            
            String CurLine;
            String[] Piecewise;
            int Section = -1;   //Section 0 : Drawing Task Section 1 : General Information
                                //Section 2 : Geometric Entity
            StreamReader TaskText = new StreamReader(openFileDialog.FileName);
            while (TaskText.Peek() >= 0)
            {
                CurLine = TaskText.ReadLine();
                if (CurLine.ToUpper().Contains("DRAWING TASK"))
                {
                    Section = 0;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GENERAL INFORMATION"))
                {
                    Section = 1;
                    continue;
                }
                else if (CurLine.ToUpper().Contains("GEOMETRIC ENTITY"))
                {
                    Section = 2;
                    continue;
                }

                switch (Section)
                {
                    case 0:     //DRAWING TASK
                        if (CurLine.ToUpper().Contains("FORMAT VERSION"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Version = Convert.ToInt32(Piecewise[1]);
                        }
                        break;

                    case 1:     //GENERAL INFORMATION
                        if (CurLine.ToUpper().Contains("LINE WIDTH"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            LineWidth = Convert.ToInt32(Piecewise[1]);
                        }
                        break;

                    case 2:     //GEOMETRIC ENTITY
                        if (CurLine.ToUpper().Contains("LINE"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            for (int i = 0; i < 4; i++)
                            {
                                Line[TotalLineNum, i] = Convert.ToInt32(Piecewise[i]);

                            }
                            TotalLineNum++;
                        }
                        else if (CurLine.ToUpper().Contains("CIRCLE"))
                        {
                            Piecewise = CurLine.Trim().Split(':');
                            Piecewise = Piecewise[1].Trim().Split(' ');
                            for (int i = 0; i < 3; i++)
                            {
                                Circle[TotalCircleNum, i] = Convert.ToInt32(Piecewise[i]);

                            }
                            TotalCircleNum++;
                        }

                        break;
                }
            }
        }
        private void button_load_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                LoadTaskFile(openFileDialog.FileName);
                listBox_line.Items.Clear();
                for (int i = 0; i < TotalLineNum; i++)
                {
                    listBox_line.Items.Add("( " + Line[i, 0] + ", " + Line[i, 1] + " ) to ( " + Line[i, 2] + ", " + Line[i, 3] + " )");
                }
                listBox_circle.Items.Clear();
                for (int i = 0; i < TotalCircleNum; i++)
                {
                    listBox_circle.Items.Add("( " + Circle[i, 0] + ", " + Circle[i, 1] + " ) R ( " + Circle[i, 2] + " )");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Line = new int[99, 4];
            TotalLineNum = 0;
            Circle = new int[99, 3];
            TotalCircleNum = 0;
            LineWidth = -1;
            openFileDialog.Filter = "Task Files (*.tsk)|*.tsk|All Files(*.*)|*.*";
            openFileDialog.FileName = "";
            openFileDialog.Title = "Open a Task,please!";

            DirectoryInfo ProjectDir = new DirectoryInfo(Application.StartupPath);
            openFileDialog.InitialDirectory = ProjectDir.Parent.Parent.FullName;

            g = this.paneldrawing.CreateGraphics();
        }

        private void paneldrawing_Paint(object sender, PaintEventArgs e)
        {
            //當畫面有需要更新後留在畫面之中的時候，都要在paint的事件中執行
            //考試可能會考
            Pen pen = new Pen(Color.Red, LineWidth);

            for (int i = 0; i < listBox_line.SelectedIndices.Count; i++)
            {
                g.DrawLine(pen, Line[listBox_line.SelectedIndices[i], 0],
                                Line[listBox_line.SelectedIndices[i], 1],
                                Line[listBox_line.SelectedIndices[i], 2],
                                Line[listBox_line.SelectedIndices[i], 3]);
            }

            for (int i = 0; i < listBox_circle.SelectedIndices.Count; i++)
            {
                g.DrawEllipse(pen, Circle[listBox_circle.SelectedIndices[i], 0],
                                   Circle[listBox_circle.SelectedIndices[i], 1],
                                   Circle[listBox_circle.SelectedIndices[i], 2], 
                                   Circle[listBox_circle.SelectedIndices[i], 2]);
            }
        }

        private void listBox_line_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        private void listBox_circle_SelectedIndexChanged(object sender, EventArgs e)
        {
            Refresh();
        }
    }
}
