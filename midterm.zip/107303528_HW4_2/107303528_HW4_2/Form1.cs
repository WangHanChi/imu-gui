﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW4_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_open_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                String Filename = openFileDialog.FileName;
                String[] str = Filename.Split('.');
                String FileType = str[str.Count()-1];

                if (FileType == "rtf")
                {
                    richTextBox1.LoadFile(Filename, RichTextBoxStreamType.RichText);
                }
                else if (FileType == "txt")
                {
                    richTextBox1.LoadFile(Filename, RichTextBoxStreamType.PlainText);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            openFileDialog.FileName = "";
            openFileDialog.Filter = "Rich Test (*.RTF)|*.rtf|Plain Text(*.txt)|*.txt|All Files(*.*)|*.*";
            saveFileDialog.Filter = "Rich Test (*.RTF)|*.rtf|Plain Text(*.txt)|*.txt|All Files(*.*)|*.*";
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                String Filename = saveFileDialog.FileName;
                String[] str = Filename.Split('.');
                String FileType = str[str.Count() - 1];

                if (FileType == "rtf")
                {
                    richTextBox1.SaveFile(Filename, RichTextBoxStreamType.RichText);
                }
                else if (FileType == "txt")
                {
                    richTextBox1.SaveFile(Filename, RichTextBoxStreamType.PlainText);
                }
            }
        }

        private void button_font_Click(object sender, EventArgs e)
        {
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont = fontDialog.Font;
            }
        }

        private void button_Color_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = colorDialog.Color;
            }
        }
    }
}
