﻿namespace _107303528_HW3_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private int Count = 0;
        private int picBoxLocX;
        private int picBoxLocY;
        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label_speed = new System.Windows.Forms.Label();
            this.pictureBox_frog = new System.Windows.Forms.PictureBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.imageList_frog = new System.Windows.Forms.ImageList(this.components);
            this.timer_Animation = new System.Windows.Forms.Timer(this.components);
            this.timer_Runner = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_speed
            // 
            this.label_speed.AutoSize = true;
            this.label_speed.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_speed.Location = new System.Drawing.Point(143, 91);
            this.label_speed.Name = "label_speed";
            this.label_speed.Size = new System.Drawing.Size(61, 24);
            this.label_speed.TabIndex = 0;
            this.label_speed.Text = "speed";
            this.label_speed.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox_frog
            // 
            this.pictureBox_frog.Location = new System.Drawing.Point(664, 38);
            this.pictureBox_frog.Name = "pictureBox_frog";
            this.pictureBox_frog.Size = new System.Drawing.Size(348, 290);
            this.pictureBox_frog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_frog.TabIndex = 1;
            this.pictureBox_frog.TabStop = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.numericUpDown1.Location = new System.Drawing.Point(285, 89);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(130, 36);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // imageList_frog
            // 
            this.imageList_frog.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList_frog.ImageStream")));
            this.imageList_frog.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList_frog.Images.SetKeyName(0, "p1.gif");
            this.imageList_frog.Images.SetKeyName(1, "p2.gif");
            this.imageList_frog.Images.SetKeyName(2, "p3.gif");
            this.imageList_frog.Images.SetKeyName(3, "p4.gif");
            this.imageList_frog.Images.SetKeyName(4, "p5.gif");
            this.imageList_frog.Images.SetKeyName(5, "p6.gif");
            // 
            // timer_Animation
            // 
            this.timer_Animation.Tick += new System.EventHandler(this.timer_Animation_Tick);
            // 
            // timer_Runner
            // 
            this.timer_Runner.Tick += new System.EventHandler(this.timer_Runner_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 662);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.pictureBox_frog);
            this.Controls.Add(this.label_speed);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.Form1_Click);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_frog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_speed;
        private System.Windows.Forms.PictureBox pictureBox_frog;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ImageList imageList_frog;
        private System.Windows.Forms.Timer timer_Animation;
        private System.Windows.Forms.Timer timer_Runner;
    }
}

