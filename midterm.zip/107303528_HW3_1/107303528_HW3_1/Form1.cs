﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW3_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer_Animation_Tick(object sender, EventArgs e)
        {
            if (Count > 5) {
                Count = 0;
            }
            pictureBox_frog.Image = imageList_frog.Images[Count];
            Count++;
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            timer_Animation.Start();
            timer_Runner.Start();

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            timer_Animation.Interval = (int) numericUpDown1.Value;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Count = 0;
            picBoxLocX = (this.Width/2 - pictureBox_frog.Width/2);
            picBoxLocY = (this.Height/2 - pictureBox_frog.Height/2);

        }

        private void timer_Runner_Tick(object sender, EventArgs e)
        {
            picBoxLocX -= 5;
            if ((picBoxLocX + pictureBox_frog.Width) < 0) {
                picBoxLocX = this.Width;
            }
            pictureBox_frog.Location = new Point(picBoxLocX, picBoxLocY);
            
        }
    }
}
