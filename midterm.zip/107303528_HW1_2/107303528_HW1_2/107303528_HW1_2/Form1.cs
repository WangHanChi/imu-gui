﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button_sum_Click(object sender, EventArgs e)
        {
         
            double input1 = Convert.ToDouble(input_value1.Text);
            double input2 = Convert.ToDouble(input_value2.Text);
            double sum = input1 + input2;
            output_num.Text = Convert.ToString(sum); 
        }
    }
}
