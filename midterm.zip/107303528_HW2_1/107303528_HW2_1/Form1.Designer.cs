﻿namespace _107303528_HW2_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.hScrollBar_Ages = new System.Windows.Forms.HScrollBar();
            this.vote_box = new System.Windows.Forms.GroupBox();
            this.input_age = new System.Windows.Forms.TextBox();
            this.output = new System.Windows.Forms.TextBox();
            this.vote_box.SuspendLayout();
            this.SuspendLayout();
            // 
            // hScrollBar_Ages
            // 
            this.hScrollBar_Ages.Location = new System.Drawing.Point(47, 76);
            this.hScrollBar_Ages.Maximum = 109;
            this.hScrollBar_Ages.Name = "hScrollBar_Ages";
            this.hScrollBar_Ages.Size = new System.Drawing.Size(493, 80);
            this.hScrollBar_Ages.TabIndex = 0;
            this.hScrollBar_Ages.Value = 50;
            this.hScrollBar_Ages.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_Ages_Scroll);
            // 
            // vote_box
            // 
            this.vote_box.Controls.Add(this.input_age);
            this.vote_box.Controls.Add(this.hScrollBar_Ages);
            this.vote_box.Controls.Add(this.output);
            this.vote_box.Location = new System.Drawing.Point(85, 29);
            this.vote_box.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vote_box.Name = "vote_box";
            this.vote_box.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vote_box.Size = new System.Drawing.Size(896, 416);
            this.vote_box.TabIndex = 1;
            this.vote_box.TabStop = false;
            this.vote_box.Text = "vote_box";
            this.vote_box.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // input_age
            // 
            this.input_age.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.input_age.Location = new System.Drawing.Point(656, 116);
            this.input_age.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.input_age.Name = "input_age";
            this.input_age.Size = new System.Drawing.Size(132, 39);
            this.input_age.TabIndex = 3;
            this.input_age.TextChanged += new System.EventHandler(this.input_age_TextChanged);
            // 
            // output
            // 
            this.output.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.output.Location = new System.Drawing.Point(76, 291);
            this.output.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(585, 39);
            this.output.TabIndex = 2;
            this.output.TextChanged += new System.EventHandler(this.output_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1393, 884);
            this.Controls.Add(this.vote_box);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.vote_box.ResumeLayout(false);
            this.vote_box.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.HScrollBar hScrollBar_Ages;
        private System.Windows.Forms.GroupBox vote_box;
        private System.Windows.Forms.TextBox input_age;
        private System.Windows.Forms.TextBox output;
    }
}

