﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _107303528_HW2_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void output_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void hScrollBar_Ages_Scroll(object sender, ScrollEventArgs e)
        {
            int age = hScrollBar_Ages.Value;
            input_age.Text = age.ToString();
        }

        private void input_age_TextChanged(object sender, EventArgs e)
        {
            if (input_age.Text == "")
            {
                return;
            }
            int age = Convert.ToInt32(input_age.Text);
            if (age > 100)
            {
                age = 100;
                input_age.Text = age.ToString();
            }
                
            hScrollBar_Ages.Value = age;
            if (age >= 20)
            {
                output.ForeColor = Color.Blue;
                output.Text = "You have the vote right.";
            }
            else if (age < 20)
            {
                output.ForeColor = Color.Red;
                output.Text = "You don't have the vote right.";
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
